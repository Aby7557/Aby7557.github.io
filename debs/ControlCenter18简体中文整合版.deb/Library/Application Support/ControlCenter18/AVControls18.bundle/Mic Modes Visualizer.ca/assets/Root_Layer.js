clearLogging()

var emitterLayer

function ready() {
   emitterLayer = findLayer("particles")
}

function eventHandler(e) {
   if (e.type == "statechanged") {
      let stateName = (document.state() || {}).name
      if (stateName == "voice isolation" || "") {
         emitterLayer.emitterCells[0].color = new Color(1, 1, 1, 0.07)
         emitterLayer.emitterCells[1].color = new Color(1, 1, 1, 0)
         emitterLayer.emitterCells[2].color = new Color(1, 1, 1, 0)

      } else if (stateName == "standard") {
         emitterLayer.emitterCells[0].color = new Color(1, 1, 1, 0.07)
         emitterLayer.emitterCells[1].color = new Color(1, 1, 1, 0.05)
         emitterLayer.emitterCells[2].color = new Color(1, 1, 1, 0)

      } else if (stateName == "wide spectrum") {
         emitterLayer.emitterCells[0].color = new Color(1, 1, 1, 0.07)
         emitterLayer.emitterCells[1].color = new Color(1, 1, 1, 0.05)
         emitterLayer.emitterCells[2].color = new Color(1, 1, 1, 0.03)
      }
   }
}

function updateForDisplay(displayLink) {
   Transaction.disableActions = true

   let deltaTime = displayLink.duration
   displayLink.preferredFramesPerSecond = 120

   var wavesDetails = [
      // speed, falloffStart, falloffEnd
      [2, -500, 150],
      [1, 200, -400],
      [0.8, 400, -100],
   ]

   const numberOfWaves = 3
   for (var idx = 0; idx < numberOfWaves; idx++) {
      let waveCell = emitterLayer.emitterCells[idx]
      let waveBehaviors = emitterLayer.emitterCells[idx].emitterBehaviors
      let waveDetails = wavesDetails[idx]

      // falloff distance based on current time
      let timeOffset = currentTime() * waveDetails[0]
      falloffDistanceOffset = Math.map(Math.sin(timeOffset), -1, 1, waveDetails[1], waveDetails[2])
      waveBehaviors[1].setValueForKeyPath(falloffDistanceOffset, "falloffDistance")

      emitterLayer.reloadValueForKeyPath("emitterCells")
      waveCell.emitterBehaviors = waveBehaviors
   }
}

// Utils

Math.map = function(value, inputMin, inputMax, outputMin, outputMax) {
   return outputMin + ((outputMax - outputMin) * ((value - inputMin) / (inputMax - inputMin)))
}

Math.clamp = function(value, inputMin, inputMax) {
   if (value < inputMin)
      return inputMin

   if (value > inputMax)
      return inputMax

   return value
}
